# InstructERC on MELD + EmoryNLP (causal next-emotion forecasting)

Same InstructERC baseline as IEMOCAP, adapted to MELD's and EmoryNLP's 7-class
label sets. Same causal task (history -> next emotion, no x_t), same retrieval
(train-only, leak-free), same evaluator.

## Step 1 — build the dataset pickles (run once, anywhere the raw files are)
Put the raw files in one folder:
  MELD:     train_sent_emo.csv, dev_sent_emo.csv, test_sent_emo.csv
  EmoryNLP: emotion-detection-trn.json, emotion-detection-dev.json, emotion-detection-tst.json

```bash
python convert/make_pickles.py --dataset meld     --meld_dir  /path/to/raw --out meld.pkl
python convert/make_pickles.py --dataset emorynlp --emory_dir /path/to/raw --out emorynlp.pkl
```

## Step 2 — train + eval (set ERC_DATASET so the right label set loads)

MELD:
```bash
export ERC_DATASET=meld
python b6_instructerc/run.py --mode train --data_path meld.pkl \
  --base_model Qwen/Qwen2.5-3B-Instruct --k 4 --epochs 3 --seed 42 \
  --output_dir /root/out/instructerc_meld
python b6_instructerc/run.py --mode eval  --data_path meld.pkl \
  --base_model Qwen/Qwen2.5-3B-Instruct --k 4 --seed 42 \
  --model_path /root/out/instructerc_meld --split test \
  --save_path /workspace/results/instructerc_meld_s42.json
```

EmoryNLP (same, swap the env var + paths):
```bash
export ERC_DATASET=emorynlp
python b6_instructerc/run.py --mode train --data_path emorynlp.pkl \
  --base_model Qwen/Qwen2.5-3B-Instruct --k 4 --epochs 3 --seed 42 \
  --output_dir /root/out/instructerc_emory
python b6_instructerc/run.py --mode eval  --data_path emorynlp.pkl \
  --base_model Qwen/Qwen2.5-3B-Instruct --k 4 --seed 42 \
  --model_path /root/out/instructerc_emory --split test \
  --save_path /workspace/results/instructerc_emory_s42.json
```

IMPORTANT: always `export ERC_DATASET=meld` (or emorynlp) in the SAME shell before
both train and eval, so the correct 7-class label set is active.

## Label sets
- MELD:     neutral, surprise, fear, sadness, joy, disgust, anger
- EmoryNLP: neutral, joyful, powerful, mad, sad, scared, peaceful

## Split sizes (forecasting samples, t>=1)
- MELD:     train 8951 / dev 995 / test 2330   (dialogues 1038/114/280 — matches DPM)
- EmoryNLP: train 9221 / dev 1245 / test 1243  (scenes 713/99/85 — slightly larger
            than DPM's 659/89/79; DPM used extra filtering, so EmoryNLP numbers are
            on a marginally different split. Note this when comparing to DPM.)


## Retrieval leakage fix
Retrieval excludes any demo sharing the query CONVERSATION (conv_id), for both train and eval pools. Earlier versions compared a per-sample id and only excluded the identical sample, allowing same-dialogue turns (which include the target turn with its gold label) to leak into training prompts. Fixed and verified: 0 same-conversation demos across sampled queries.
